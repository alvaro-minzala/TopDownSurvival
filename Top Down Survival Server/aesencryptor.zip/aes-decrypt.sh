#!/bin/bash
DIR=$( cd "$( dirname "$0" )" && pwd )
source "$DIR/aes-encrypt.sh"
